package com.accenture.pessoa_Swagger.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accenture.pessoa_Swagger.entity.Pessoa;
import com.accenture.pessoa_Swagger.repository.PessoaRepository;

@Service
public class PessoaService {
	
    @Autowired
    private PessoaRepository pessoaRepository;

    public List<Pessoa> getAllPessoas() {
		List<Pessoa> pessoas = new ArrayList<Pessoa>();
		pessoaRepository.findAll().forEach(pessoa -> pessoas.add(pessoa));
		return pessoas;
    }

    public Pessoa getPessoaById(int id) {
        Optional<Pessoa> pessoa = pessoaRepository.findById(id);
        return pessoa.orElse(null);
    }

    public Pessoa saveOrUpdate(Pessoa pessoa) {
            Optional<Pessoa> existingPessoa = pessoaRepository.findById(pessoa.getId());
            if (existingPessoa.isPresent()) {
                Pessoa updatedPessoa = existingPessoa.get();
                updatedPessoa.setNome(pessoa.getNome());
                return pessoaRepository.save(updatedPessoa);
        }
        // Se o ID da pessoa estiver nulo ou se não encontrou uma pessoa existente, é uma criação
        return pessoaRepository.save(pessoa);
    }

    public boolean delete(int id) {
        Optional<Pessoa> pessoa = pessoaRepository.findById(id);
        if (pessoa.isPresent()) {
            pessoaRepository.delete(pessoa.get());
            return true;
        }
        return false;
    }

}
