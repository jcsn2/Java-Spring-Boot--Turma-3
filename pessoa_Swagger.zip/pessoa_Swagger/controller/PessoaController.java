package com.accenture.pessoa_Swagger.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.pessoa_Swagger.entity.Pessoa;
import com.accenture.pessoa_Swagger.repository.PessoaRepository;
import com.accenture.pessoa_Swagger.service.PessoaService;

@RestController
public class PessoaController {
	
	@Autowired
	PessoaService pessoaService;

    @RequestMapping(value = "/pessoa", method = RequestMethod.GET)
    public List<Pessoa> getAllPessoas() {
        return pessoaService.getAllPessoas();
    }

    @RequestMapping(value = "/pessoa/{id}", method = RequestMethod.GET)
    public ResponseEntity<Pessoa> getPessoaById(@PathVariable(value = "id") int id) {
        Pessoa pessoa = pessoaService.getPessoaById(id);
        return new ResponseEntity<>(pessoa, HttpStatus.OK);
    }

    @RequestMapping(value = "/pessoa", method = RequestMethod.POST)
    public ResponseEntity<Pessoa> saveOrUpdate(@Valid @RequestBody Pessoa pessoa) {
        Pessoa savedPessoa = pessoaService.saveOrUpdate(pessoa);
        return new ResponseEntity<>(savedPessoa, HttpStatus.OK);
    }

    @RequestMapping(value = "/pessoa/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Object> delete(@PathVariable(value = "id") int id) {
        boolean deleted = pessoaService.delete(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}